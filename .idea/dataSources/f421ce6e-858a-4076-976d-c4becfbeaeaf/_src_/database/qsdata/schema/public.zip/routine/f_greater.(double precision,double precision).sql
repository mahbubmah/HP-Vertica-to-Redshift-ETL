create function f_greater(a double precision, b double precision) returns double precision
STABLE
LANGUAGE plpythonu
AS $$
  if a > b:
    return a
  return b
$$;
