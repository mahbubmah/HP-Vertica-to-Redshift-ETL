CREATE FUNCTION f_greater(a double precision, b double precision)
  RETURNS double precision
  STABLE
  LANGUAGE plpythonu
AS $$
  if a > b:
    return a
  return b
$$;

